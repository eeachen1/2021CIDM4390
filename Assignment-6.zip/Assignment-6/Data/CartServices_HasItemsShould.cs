using Xunit;
using Prime.Services;

namespace Prime.UnitTests.Services
{
    public class PrimeService_IsPrimeShould
    {
                [Theory]
                [InlineData(0)]
                [InlineData(1)]
        public void Has_Items_More_Than_0(int value)
        {
            var result = _primeService.HasItems(value);

            Assert.False(result, $"Cart can not have {value} items, please add more.");
        }
    }
}