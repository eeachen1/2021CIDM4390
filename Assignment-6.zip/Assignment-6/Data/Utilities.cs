using System;

namespace Cart.Services
{
    public class CartItems
    {
        public bool IsPrime(int candidate)
        {
            if (candidate == 0)
            {
                return false;
            }
            throw new NotImplementedException("Not fully implemented.");
        }
    }
}